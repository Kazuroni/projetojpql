package br.fatec.edu.fatec;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FatecApplicationTests {

	@Test
	void contextLoads() {
	}

}
